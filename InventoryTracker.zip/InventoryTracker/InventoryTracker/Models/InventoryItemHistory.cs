﻿namespace InventoryTracker.Models
{
    public class InventoryItemHistory
    {
        public int Id { get; set; }
        public int InventoryItemId { get; set; }
        public string ChangeType { get; set; }
        public DateTime ChangeTime { get; set; }
        public string ChangedBy { get; set; }
        // Add any other properties as needed
    }
}
