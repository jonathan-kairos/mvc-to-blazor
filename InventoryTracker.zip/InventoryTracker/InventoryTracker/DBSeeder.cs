﻿using InventoryTracker.Models;
using Microsoft.EntityFrameworkCore;

namespace InventoryTracker
{
    public static class DbSeeder
    {
        public static void Seed(InventoryDbContext context)
        {
            // Check if the database has been seeded
            if (context.InventoryItems.Any())
            {
                return; // Database has been seeded
            }

            // Seed the database with 100 random inventory items
            var rand = new Random();
            for (int i = 1; i <= 100; i++)
            {
                context.InventoryItems.Add(new InventoryItem
                {
                    Name = $"Item {i}",
                    Description = $"Description for Item {i}",
                    Quantity = rand.Next(1, 100),
                    Price = rand.Next(1, 1000)
                });
            }

            context.SaveChanges(); // Save changes to the database
        }
    }
}
