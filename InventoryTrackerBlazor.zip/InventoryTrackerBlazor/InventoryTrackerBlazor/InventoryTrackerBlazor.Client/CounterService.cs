﻿namespace InventoryTrackerBlazor.Client
{
    public class CounterService
    {
        private int count = 0;

        public int GetCount()
        {
            return count;
        }

        public void SetCount(int newCount)
        {
            count = newCount;
        }
    }

}
